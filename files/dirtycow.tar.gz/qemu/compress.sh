#!/bin/bash

privPrefix=""

if [[ "${1}" == "--gzip" ]]; then
    compress="gzip"
    shift 1
fi

if [[ "${1}" == "--overwrite" ]]; then
    overwrite=true
    shift 1
fi 

if [ $# -lt 1 ]; then
    echo "${0} [--gzip] [--overwrite] <directory to compress> [filename]"
    exit 1
fi

directory="${1}"

if [ ! -d $directory ]; then
    echo "Directory '$directory' does not exist"
    exit 1
fi

if [ -n "${2}" ]; then
    filename="${2}"
else
    filename=`echo $directory | rev | cut -d '/' -f1 | rev`
    filename="${filename}.cpio"
fi

if [[ -a $filepath && "$overwrite" != true ]]; then
    echo "File '$filename' already exists, use --overwrite to force overwrite"
    exit 1
fi

if [[ "$filename" == *.gz ]]; then
    compress="gzip"
    filename=${filename::-3}
fi

if [[ "$filename" != *.cpio* ]]; then
    filename="$filename.cpio"
fi

if [[ "$filename" != /* ]]; then
    filepath=${PWD}/$filename
else
    filepath=$filename
fi

if [[ "$(id -u)" != "0" ]]; then
    privPrefix="sudo"
fi

pushd $directory
$privPrefix find . | $privPrefix cpio -o -H newc -R root:root > $filepath
popd

if [ -n "$compress" ]; then
    if [[ "$compress" == "gzip" ]]; then
        gzip -f $filename
    fi
fi