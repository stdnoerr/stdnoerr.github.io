#!/bin/bash
kernel=$1
initramfs=$2

qemu-system-x86_64 -m 256M -nographic -no-reboot -monitor /dev/null -serial mon:stdio \
    -kernel $kernel \
    -initrd $initramfs \
    -cpu kvm64 \
    -smp cores=2,threads=2 \
    -append "console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr" \
    -s
