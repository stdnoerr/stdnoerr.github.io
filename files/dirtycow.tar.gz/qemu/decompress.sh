#!/bin/bash

prefix=""
privPrefix="sudo"

if [ $# -lt 1 ]; then
    echo "${0} <file to decompress> [directory to extract to]"
    exit 1
fi

filepath="${1}"

if [ ! -f "$filepath" ]; then
    echo "Error: File '$filepath' does not exist or is not a regular file."
    exit 2
fi

if [[ "$filepath" != /* ]]; then
filepath="$PWD/$filepath"
fi

filename=`echo "$filepath"| rev | cut -d '/' -f1 | rev`

if [ $# -eq 1 ]; then
directory=`echo "$filepath"| rev | cut -d '/' -f1 | rev | cut -d '.' -f1`
else
directory="${2}"
fi

if [ "$(id -u)" -ne 0 ]; then
privPrefix="sudo"
fi

if [ ! -d $directory ]; then
$prefix mkdir -p $directory
fi

originalPath=''

if [[ "$filename" == *.gz ]]; then
$prefix cp $filepath $directory
$prefix pushd $directory
$prefix gunzip $filename
$prefix popd
originalPath=$filepath
filepath=${filename::-3}
fi

$prefix pushd $directory
$prefix $privPrefix cpio -idm < $filepath
$prefix popd

if [ ! -z "$originalPath" ]; then
$prefix rm -f $directory/$filepath
fi
