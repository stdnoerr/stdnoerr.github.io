#!/bin/bash
qemu/decompress.sh qemu/initramfs.cpio.gz fs
gcc exploit.c -o fs/exploit -static || exit
qemu/compress.sh fs qemu/initramfs.cpio.gz

qemu/run.sh qemu/bzImage qemu/initramfs.cpio.gz
